var table = jQuery('#patient_show_all_data').DataTable({});
jQuery('#add_new_patient').click(function() {
    jQuery.ajax({
        url   : ajax_path.admin_url ,
        method  : 'post',
        data : {
            action :'addpatient',
            'name' : jQuery('#patient_fullname').val(),
            'age' : jQuery('#patient_age').val(),
            'gender' : jQuery('#patient_gender').val(),
            'visitdate' : jQuery('#patient_date').val(),
            'address' : jQuery('#patient_address').val(),
            'phone' : jQuery('#patient_number').val()
        },
        success:function(response) {
            jQuery('#adding_new_patient_form').html('<h5 style="text-align:justify">' + response + '</h5>');
            setTimeout(function() {
                location.reload();
            }, 1000);
        }
    });
});

jQuery('.update_patient_info').click(function() {
    var patientId = jQuery(this).data('patient');
    jQuery.ajax({
        url   : ajax_path.admin_url ,
        method  : 'post',
        data : {
            action :'updatepatient',
            'patientId' : patientId,
            'name' : jQuery('#patient_fullname-'+patientId).val(),
            'age' : jQuery('#patient_age-'+patientId).val(),
            'gender' : jQuery('#patient_gender-'+patientId).val(),
            'visitdate' : jQuery('#patient_date-'+patientId).val(),
            'address' : jQuery('#patient_address-'+patientId).val(),
            'phone' : jQuery('#patient_number-'+patientId).val(),
            'visits' : jQuery('#patient_visits-'+patientId).val(),
        },
        success:function(response) {
            jQuery('#edit_patient_form-'+patientId).html('<h5 style="text-align:justify">' + response + '</h5>');
            setTimeout(function() {
                location.reload();
            }, 1000);
        }
    });
});

jQuery('.delete_patient_info').click(function() {
    var patientId = jQuery(this).data('patient');
    jQuery.ajax({
        url   : ajax_path.admin_url ,
        method  : 'post',
        data : {
            action :'deletepatient',
            'patientId' : patientId
        },
        success:function(response) {
            jQuery('#delete_patient_form-'+patientId).html('<h5 style="text-align:justify">' + response + '</h5>');
            setTimeout(function() {
                location.reload();
            }, 1000);
        }
    });
});