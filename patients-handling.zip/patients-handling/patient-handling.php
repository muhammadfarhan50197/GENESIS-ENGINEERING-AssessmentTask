<?php
/**
*Plugin Name: Patient Handling
*Description: This plugin handles all operations including showing, adding, saving, editing, and deleting patients. You can add this shortcode "[patient_dashboard]" on any page to access the patient dashboard view.
*Version: 1.0.0
*Author: Muhammad Farhan
*License: GPL2
*/

if ( ! defined( 'WPINC' ) ) { //check wp includes folder is present or not
  wp_die();
}
if ( !class_exists( 'PH_Patient' ) ) :
    class PH_Patient {
        public function __construct() {
            $this->PH_define_paths();
            add_action('init', array($this, 'PH_register_patient'));
			add_action( 'add_meta_boxes',  array($this, 'add_meta_box_against_post' ));
            add_action( 'save_post', array($this, 'savepatient_info' ));
            add_shortcode( 'patient_dashboard', array($this, 'PH_show_patients') );
            add_action('wp_ajax_nopriv_addpatient', array($this, 'addpatient'));
            add_action('wp_ajax_addpatient', array($this, 'addpatient'));
            add_action('wp_ajax_nopriv_updatepatient', array($this, 'updatepatient'));
            add_action('wp_ajax_updatepatient', array($this, 'updatepatient'));
            add_action('wp_ajax_nopriv_deletepatient', array($this, 'deletepatient'));
            add_action('wp_ajax_deletepatient', array($this, 'deletepatient'));
            if (!is_admin()) :
                add_action('init', array($this, 'PH_loading_script'));
                add_action('wp_loaded', array($this, 'PH_loading_script'));
                add_action('wp_footer', array($this, 'PH_loading_script'));
            endif;
        }

        public function PH_define_paths() {
		
			if ( !defined( 'PH_URL' ) ) {
				define( 'PH_URL', plugin_dir_url( __FILE__ ) );
			}

			if ( !defined( 'PH_BASENAME' ) ) {
				define( 'PH_BASENAME', plugin_basename( __FILE__ ) );
			}

			if ( ! defined( 'PH_PLUGIN_DIR' ) ) {
				define( 'PH_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
			}
		}

        public function PH_loading_script() {
            wp_enqueue_script('jquery');
            wp_enqueue_script('jquery-form');
            wp_enqueue_style('patient-bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css', false, '1.0', 'all');
            wp_enqueue_style('patient-datatable-css', 'https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css', false, '1.0', 'all');
            wp_enqueue_style('patient-css', PH_URL . 'assets/css/patient.css' , false, '1.0', 'all');
            wp_enqueue_script('patient-bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js', false, '1.0', 'all');
            wp_enqueue_script('patient-datatable-js', 'https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js', false, '1.0', 'all');
            wp_enqueue_script('patient-js', PH_URL . 'assets/js/patient.js' , false, '1.0', 'all');
            $ajaxURL = array('admin_url' => admin_url('admin-ajax.php'));
            wp_localize_script('patient-js', 'ajax_path', $ajaxURL);
        }

        public function PH_register_patient() {
            $PH_patient_labels = array(
                'name'                  => _x('Patients', 'patient_handling'),
                'singular_name'         => _x('Patient', 'patient_handling'),
                'menu_name'             => _x('Patients', 'patient_handling'),
                'name_admin_bar'        => _x('Patients', 'patient_handling'),
                'add_new'               => __('Add New', 'patient_handling'),
                'add_new_item'          => __('Add New patient', 'patient_handling'),
                'new_patient'           => __('New patient', 'patient_handling'),
                'edit_patient'          => __('Edit patient', 'patient_handling'),
                'view_patient'          => __('View patient', 'patient_handling'),
                'all_patients'          => __('All patients', 'patient_handling')
            );

            $PH_patient_arguments = array(
                'labels'                => $PH_patient_labels,
                'public'                 => true,
                'publicly_queryable'     => true,
                'show_ui'                => true,
                'show_in_menu'           => true,
                'query_var'              => true,
                'capability_type'        => 'post',
                'has_archive'            => true,
                'hierarchical'           => false,
                'menu_position'          => null,
                'field'                  => 'value',
                'menu_icon'              => 'dashicons-groups',
                'taxonomies'             => array(''),
                'supports'               => array(
                                            'title', // Add the title field
                                            'thumbnail', // Add the thumbnail
                                            'editor' // Add the content field
                                        ),
                'show_in_rest'          => true
            );
            register_post_type('PH_patient', $PH_patient_arguments);
        }
		public function add_meta_box_against_post() {
			add_meta_box(
				'patient_info',
				'Patient Information',
				array($this, 'patient_info'),
				'PH_patient',
			);
		}

		public function patient_info( $post ) {
			?>
            <style>
                .row {
                    display: flex;
                    margin-bottom: 2%;
                    gap: 30px;
                }
                .row .col {
                    width:50%
                }
                .row .col label {
                    width: 20%;
                }
                .row .col :where(input, select, textarea) {
                    width: 100%;
                }
            </style>
            <div class="row" >
                <div class="col">
                    <label>Age</label>
                    <input type="text" class="form-control" name="patient_age" placeholder="Age" value="<?php echo get_post_meta($post->ID, '_age', true); ?>" />
                </div>
                <div class="col">
                    <label>Phone Number</label>
                    <input type="text" class="form-control" name="patient_phone" placeholder="Phone Number" value="<?php echo get_post_meta($post->ID, '_phone', true); ?>" />
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Visited Date</label>
                    <input type="date" class="form-control" name="patient_date" placeholder="Visit Date" value="<?php echo get_post_meta($post->ID, '_visit_date', true); ?>" />
                </div>
                <div class="col">
                    <label>Gender</label>
                    <select class="form-select" name="patient_gender">
                        <option>Choose Gender...</option>
                        <option <?php if(get_post_meta($post->ID, '_gender', true) == 'Male') : echo 'selected'; endif; ?>>Male</option>
                        <option <?php if(get_post_meta($post->ID, '_gender', true) == 'Female') : echo 'selected'; endif; ?>>Female</option>
                        <option <?php if(get_post_meta($post->ID, '_gender', true) == 'Other') : echo 'selected'; endif; ?>> Other</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Address</label>
                    <textarea name="patient_adress"><?php echo get_post_meta($post->ID, '_address', true); ?></textarea>
                </div>
                <div class="col">
                    <label>Number of visits</label>
                    <input name="patient_visits" type="number" value="<?php echo get_post_meta($post->ID, '_visits', true); ?>">
                </div>
            </div>
			<?php
		}
        public function savepatient_info($post_id) {
            if ( wp_is_post_revision( $post_id ) ) {
                return;
            }
            update_post_meta($post_id, '_phone', $_POST['patient_phone']);
            update_post_meta($post_id, '_age', $_POST['patient_age']);
            update_post_meta($post_id, '_visit_date', $_POST['patient_date']);
            update_post_meta($post_id, '_gender', $_POST['patient_gender']);
            update_post_meta($post_id, '_address', $_POST['patient_adress']);
            update_post_meta($post_id, '_visits', $_POST['patient_visits']);
        }
        public function PH_show_patients() {
            ob_start();
				echo '<div id="patient_dashboard_view">';
				$user = wp_get_current_user();
				if (in_array('administrator', $user->roles)) :
					include PH_PLUGIN_DIR . 'templates/create-new-patient.php';
				endif;
				include PH_PLUGIN_DIR .'templates/show-all-patients.php';
				echo '</div>';
            return ob_get_clean();
        }
         public function addpatient() {
            $postID = wp_insert_post( 
                array(
                    'post_type' => 'PH_patient',
                    'post_status' => 'publish',
                    'post_title' => $_REQUEST['name'],
                    'author' => get_current_user_id()
                )
            );
            update_post_meta($postID, '_phone', $_REQUEST['phone']);
            update_post_meta($postID, '_age', $_REQUEST['age']);
            update_post_meta($postID, '_visit_date', $_REQUEST['visitdate']);
            update_post_meta($postID, '_gender', $_REQUEST['gender']);
            update_post_meta($postID, '_address', $_REQUEST['address']);
            update_post_meta($postID, '_visits', 1);
            if ($postID) :
                echo 'Your Patient has been added Successfully';
            else :
                echo 'Something went wrong';
            endif;
            wp_die();
        }
        public function updatepatient() {
            $postID = wp_update_post( 
                array(
                    'ID' => $_REQUEST['patientId'],
                    'post_title' => $_REQUEST['name']
                )
            );
            update_post_meta($postID, '_phone', $_REQUEST['phone']);
            update_post_meta($postID, '_age', $_REQUEST['age']);
            update_post_meta($postID, '_visit_date', $_REQUEST['visitdate']);
            update_post_meta($postID, '_gender', $_REQUEST['gender']);
            update_post_meta($postID, '_address', $_REQUEST['address']);
            update_post_meta($postID, '_visits', $_REQUEST['visits']);
            echo 'Your Patient has been updated Successfully';
            wp_die();
        }
        public function deletepatient() {
            $postID = wp_delete_post($_REQUEST['patientId']);
            echo 'Your Patient has been deleted Successfully';
            wp_die();
        }
    }
    new PH_Patient();
endif;
?>