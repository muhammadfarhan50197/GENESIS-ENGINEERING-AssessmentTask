<?php
/* create a new patient modal */
?>
<div class="cerate-new-patient-container">
    <button type="button" class="btn btn-primary create-new-patient-button" data-bs-toggle="modal" data-bs-target="#create-patient-modal">Add New Patient</button>
    <div class="modal fade" id="create-patient-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Create New Patient</h5>
                </div>
                <div class="modal-body">
                    <form id="adding_new_patient_form">
                        <div class="row">
							<label>Full Name</label>
							<input type="text" class="form-control" id="patient_fullname" placeholder="Full name">
                        </div>
                        <div class="row">
                            <div class="col">
								<label>Age</label>
                                <input type="text" class="form-control" id="patient_age" placeholder="Age">
                            </div>
                            <div class="col">
								<label>Phone number</label>
                                <input type="text" class="form-control" id="patient_number" placeholder="Phone Number">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
								<label>Visit Date</label>
                                <input type="date" class="form-control" id="patient_date" placeholder="Visit Date">
                            </div>
                            <div class="col">
								<label>Gender</label>
                                <select class="form-select" id="patient_gender">
                                    <option>Choose Gender...</option>
                                    <option>Male</option>
                                    <option>Female</option>
                                    <option>Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
							<label>Address</label>
                            <textarea id="patient_address" placeholder="Address"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" id="add_new_patient" class="btn btn-success">Add Patient</button>
                </div>
            </div>
        </div>
    </div>
</div>